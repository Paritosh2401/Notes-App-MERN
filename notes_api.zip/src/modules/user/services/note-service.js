import NotesModel from "../models/note-schema.js"

export const noteService{
    async addNote(noteObject){
        try {
            const doc = await NotesModel.create(noteObject);
            return doc;
        }
        catch (err) {

            throw err;
        }
    }, 
    
   async readAllNOtes(){
    try {
      const doc=  await NotesModel.find({}), () => {

        }
    }                           //use .select to fetch single data
                                                        //find method is used to find every data
    }
}