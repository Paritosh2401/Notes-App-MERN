export const Home = ()=>{
    return (<h1>Home Component</h1>)
}