// Blue Print Note
export class Note{
    constructor(id, title, descr , cdate, importance){
        this.id = id;
        this.title = title;
        this.descr = descr;
        this.cdate = cdate;
        this.importance = importance;
    }
}